#!/bin/bash

# Kiểm tra xem có đủ tham số không
if [ $# -ne 1 ]; then
    echo "Usage: $0 <stack-name>"
    exit 1
fi

# Lấy tên stack từ tham số dòng lệnh
stack_name=$1

# Xoá stack
aws cloudformation delete-stack --stack-name $stack_name
