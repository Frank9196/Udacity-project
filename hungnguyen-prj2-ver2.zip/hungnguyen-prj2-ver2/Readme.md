Update command: 
./update.sh hungnguyen-uda2 hungnguyen-infra.yml hungnguyen-infra.json
Create command: 
./create.sh hungnguyen-uda2 hungnguyen-infra.yml hungnguyen-infra.json
Delete command
./detete.sh hungnguyen-uda2

Link to check page: http://hungng-webap-gor2nmsb2glb-1279671815.us-east-1.elb.amazonaws.com/